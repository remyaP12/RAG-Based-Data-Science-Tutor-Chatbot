"""
Reads the Stackup data science course from the URL and saves every page's text
into ./notes so the chatbot can use it.

First time only:
    pip install playwright
    playwright install chromium

Run:
    python crawl_notes.py            # crawl the course
    python crawl_notes.py --login    # if the site needs login: log in once, session is saved
"""
import os, re, sys, json
from urllib.parse import urljoin, urlparse
from playwright.sync_api import sync_playwright

START_URL = "https://stackup-os.vercel.app/courses/data-science-ml"
NOTES_DIR = "notes"
AUTH_FILE = "auth.json"
MAX_PAGES = 300
# only follow links that belong to the data science course
FOLLOW = re.compile(r"data-science-ml|week|day|lesson|module", re.I)

def slug(url):
    p = urlparse(url).path.strip("/").replace("/", "_") or "home"
    return re.sub(r"[^a-zA-Z0-9_\-]", "", p)

def expand_sections(page):
    """Click accordions/tabs like 'Week 1', 'Day 2' so hidden notes become visible."""
    for _ in range(3):
        items = page.locator("button, summary, [role=tab], [aria-expanded=false]")
        n = min(items.count(), 80)
        for i in range(n):
            try:
                el = items.nth(i)
                label = (el.inner_text(timeout=300) or "")[:60]
                if re.search(r"week|day|module|lesson|note", label, re.I):
                    el.click(timeout=500)
                    page.wait_for_timeout(150)
            except Exception:
                pass

def get_text(page):
    page.wait_for_load_state("networkidle")
    page.wait_for_timeout(800)
    expand_sections(page)
    return page.inner_text("body")

def login_mode():
    with sync_playwright() as p:
        b = p.chromium.launch(headless=False)
        ctx = b.new_context()
        page = ctx.new_page()
        page.goto(START_URL)
        input("Log in in the opened browser, then press Enter here... ")
        ctx.storage_state(path=AUTH_FILE)
        b.close()
    print("Saved login to", AUTH_FILE)

def crawl():
    os.makedirs(NOTES_DIR, exist_ok=True)
    seen, queue, saved = set(), [START_URL], 0
    origin = urlparse(START_URL).netloc
    with sync_playwright() as p:
        b = p.chromium.launch(headless=True)
        ctx = b.new_context(storage_state=AUTH_FILE) if os.path.exists(AUTH_FILE) else b.new_context()
        page = ctx.new_page()
        while queue and len(seen) < MAX_PAGES:
            url = queue.pop(0).split("#")[0]
            if url in seen:
                continue
            seen.add(url)
            try:
                page.goto(url, timeout=30000)
                text = get_text(page).strip()
            except Exception as e:
                print("skip", url, e)
                continue
            if len(text) > 200:
                with open(os.path.join(NOTES_DIR, slug(url) + ".txt"), "w", encoding="utf-8") as f:
                    f.write(f"SOURCE: {url}\n\n{text}")
                saved += 1
                print("saved", url, f"({len(text)} chars)")
            for a in page.eval_on_selector_all("a[href]", "els => els.map(e => e.href)"):
                full = urljoin(url, a).split("#")[0]
                if urlparse(full).netloc == origin and full not in seen and FOLLOW.search(full):
                    queue.append(full)
        b.close()
    print(f"Done. {saved} pages saved to ./{NOTES_DIR}")

if __name__ == "__main__":
    login_mode() if "--login" in sys.argv else crawl()
