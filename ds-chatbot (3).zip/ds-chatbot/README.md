# Stackup Data Science Chatbot (URL based, Ollama, free)

Source: https://stackup-os.vercel.app/courses/data-science-ml

## One-time setup
    ollama pull llama3.2
    ollama pull nomic-embed-text
    pip install -r requirements.txt
    playwright install chromium

## If the course needs login
    python crawl_notes.py --login     # log in in the browser window, press Enter

## Run
    python chatbot.py                 # reads the URL (first time), builds index, starts API :5000
    python chatbot.py --refresh       # re-read the URL after you add new weeks/days
    python terminal_chat.py           # test in terminal (second window)

## Website call
    fetch("http://localhost:5000/chat", {method:"POST",
      headers:{"Content-Type":"application/json"},
      body: JSON.stringify({message:"What is overfitting?", history:[]})})
      .then(r => r.json()).then(d => console.log(d.answer, d.sources));

Check the ./notes folder after crawling: each week/day page should be a .txt file with real notes.
If a file only has menu text, the crawler needs a tweak for your site's layout.
