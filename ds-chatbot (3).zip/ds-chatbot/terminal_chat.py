import requests

history = []
print("Stackup DS Tutor (type 'exit' to quit)")

while True:
    q = input("\nYou: ").strip()
    if q.lower() in ("exit", "quit"):
        break
    r = requests.post(
        "http://localhost:5000/chat",
        json={"message": q, "history": history},
    ).json()
    print("\nTutor:", r.get("answer"))
    if r.get("sources"):
        print("Notes used:", ", ".join(r["sources"]))
    history += [
        {"role": "user", "content": q},
        {"role": "assistant", "content": r.get("answer", "")},
    ]