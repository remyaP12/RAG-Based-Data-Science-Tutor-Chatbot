"""
Stackup Data Science Chatbot - URL based + Ollama (free, local)

Notes come from the course URL (saved into ./notes by crawl_notes.py).
Answers ONLY data science questions, based on those notes.
Start with:  python chatbot.py            (uses saved notes; crawls automatically if none)
Refresh:     python chatbot.py --refresh  (re-reads the URL first)
"""
import os, glob, sys, subprocess
import numpy as np
import ollama
from flask import Flask, request, jsonify
from flask_cors import CORS

COURSE_URL = "https://stackup-os.vercel.app/courses/data-science-ml"
CHAT_MODEL = "llama3.2"           # ollama pull llama3.2
EMBED_MODEL = "nomic-embed-text"  # ollama pull nomic-embed-text
NOTES_DIR = "notes"
TOP_K = 4
CHUNK_CHARS = 900

SYSTEM_PROMPT = f"""You are the Stackup Data Science Tutor for the course at {COURSE_URL}.
RULES:
1. Answer ONLY questions about data science: Python for data, statistics, pandas, NumPy,
   visualization, SQL for data, machine learning, deep learning, model evaluation,
   data cleaning, feature engineering and related topics.
2. If the question is not related to data science, reply exactly:
   "Sorry, I can only help with data science topics. Please ask a data science question."
3. Base your answer on the COURSE NOTES below. Mention only the week (for example "Week 19"), never page numbers.
   Use only the notes that directly answer the question and ignore unrelated ones. Do not invent details.
4. If the notes do not cover it but it is still data science, answer briefly from general
   knowledge and clearly say it is beyond the course notes.
5. Explain simply like a teacher, with short examples or code when useful."""

# ---------- 1. Get notes from the URL ----------
def ensure_notes():
    has_notes = bool(glob.glob(os.path.join(NOTES_DIR, "*.txt")) + glob.glob(os.path.join(NOTES_DIR, "*.md")))
    if "--refresh" in sys.argv or not has_notes:
        print("Reading course from URL...")
        subprocess.run([sys.executable, "crawl_notes.py"], check=False)

def load_chunks():
    chunks = []
    for path in sorted(glob.glob(os.path.join(NOTES_DIR, "*.*"))):
        if not path.endswith((".md", ".txt")):
            continue
        name = os.path.splitext(os.path.basename(path))[0]
        buf = ""
        for line in open(path, encoding="utf-8").read().splitlines():
            line = line.strip()
            if not line:
                continue
            if len(buf) + len(line) > CHUNK_CHARS and buf:
                chunks.append({"source": name, "text": buf})
                buf = ""
            buf += line + "\n"
        if len(buf) > 40:
            chunks.append({"source": name, "text": buf})
    return chunks

def embed(text):
    return np.array(ollama.embeddings(model=EMBED_MODEL, prompt=text)["embedding"])

ensure_notes()
print("Building search index from notes...")
CHUNKS = load_chunks()
for c in CHUNKS:
    c["vec"] = embed(c["text"])
print(f"Indexed {len(CHUNKS)} chunks.")

def search_notes(question):
    if not CHUNKS:
        return []
    q = embed(question)
    scored = [(float(np.dot(q, c["vec"]) / (np.linalg.norm(q) * np.linalg.norm(c["vec"]) + 1e-9)), c)
              for c in CHUNKS]
    scored.sort(key=lambda x: x[0], reverse=True)
    return [c for s, c in scored[:TOP_K] if s > 0.45]

# ---------- 2. Topic guard ----------
def is_data_science(question):
    r = ollama.chat(model=CHAT_MODEL, messages=[
        {"role": "system", "content":
         "Reply with only YES or NO. Is the user's message about data science, statistics, "
         "machine learning, AI/ML, Python/SQL for data, data analysis or visualization? "
         "Greetings like 'hi' count as YES."},
        {"role": "user", "content": question},
    ], options={"temperature": 0})
    return r["message"]["content"].strip().upper().startswith("YES")

# ---------- 3. API ----------
app = Flask(__name__)
CORS(app)

@app.post("/chat")
def chat():
    data = request.get_json(force=True)
    question = (data.get("message") or "").strip()
    history = data.get("history", [])
    if not question:
        return jsonify({"error": "message is required"}), 400
    if not is_data_science(question):
        return jsonify({"answer": "Sorry, I can only help with data science topics. "
                                  "Please ask a data science question.", "sources": []})
    hits = search_notes(question)
    context = "\n\n".join(f"[{h['source']}]\n{h['text']}" for h in hits) or "(no matching notes)"
    messages = [{"role": "system", "content": SYSTEM_PROMPT + "\n\nCOURSE NOTES:\n" + context}]
    messages += history[-6:]
    messages.append({"role": "user", "content": question})
    reply = ollama.chat(model=CHAT_MODEL, messages=messages, options={"temperature": 0.2})
    return jsonify({"answer": reply["message"]["content"],
                    "sources": sorted({h["source"] for h in hits})})

@app.get("/")
def health():
    return {"status": "Stackup DS chatbot running", "chunks_indexed": len(CHUNKS)}

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
